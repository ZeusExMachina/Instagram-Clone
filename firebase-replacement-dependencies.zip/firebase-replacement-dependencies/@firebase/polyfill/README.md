# @firebase/polyfill

This is the a set of polyfills/shims used by the Firebase JS SDK. This package
is completely standalone and can be loaded to standardize environments for use
with the Firebase JS SDK. 

**This package is not intended for direct usage, and should only be used via the officially supported [firebase](https://www.npmjs.com/package/firebase) package.**
